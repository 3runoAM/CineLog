package com.brunoam.CineLog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CinelogApplicationTests {

	@Test
	void contextLoads() {
	}

}
